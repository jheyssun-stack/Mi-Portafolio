Calculadora Geométrica Java. Requiere JDK 8 o posterior. Ejecuta ejecutar.bat o usa: javac CalculadoraGeometrica.java y java CalculadoraGeometrica.
