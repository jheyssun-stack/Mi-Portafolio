@echo off
cd /d "%~dp0"
javac CalculadoraGeometrica.java
if errorlevel 1 pause & exit /b 1
java CalculadoraGeometrica
