package pe.jheyvx.tech.network;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import pe.jheyvx.tech.model.Product;
import pe.jheyvx.tech.service.InventoryService;
import pe.jheyvx.tech.service.SalesService;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Small line-based JSON server; each desktop request is served by a worker thread. */
public final class ApiServer implements AutoCloseable {
    private final String bindHost;
    private final int port;
    private final InventoryService inventory = new InventoryService();
    private final SalesService sales = new SalesService();
    private final Gson gson = new Gson();
    private final ExecutorService workers = Executors.newFixedThreadPool(8);
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile ServerSocket listener;
    private volatile Thread acceptThread;

    public ApiServer(String bindHost,int port){this.bindHost=bindHost;this.port=port;}

    public synchronized void start() throws Exception {
        if(running.get())return;
        listener=new ServerSocket(port,50,java.net.InetAddress.getByName(bindHost));
        running.set(true);
        acceptThread=new Thread(new Runnable(){public void run(){acceptLoop();}},"jheyvx-accept");
        acceptThread.setDaemon(true);acceptThread.start();
    }

    public int getPort(){return listener==null?port:listener.getLocalPort();}
    public boolean isRunning(){return running.get();}

    private void acceptLoop(){
        while(running.get()){
            try{final Socket client=listener.accept();client.setSoTimeout(12000);workers.submit(new Runnable(){public void run(){serve(client);}});}
            catch(Exception ex){if(running.get())System.err.println("Servidor: "+ex.getMessage());}
        }
    }

    private void serve(Socket socket){
        try(Socket client=socket;BufferedReader in=new BufferedReader(new InputStreamReader(client.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(client.getOutputStream(),true)){
            String line=in.readLine();JsonObject request=JsonParser.parseString(line).getAsJsonObject();
            JsonObject response=new JsonObject();response.addProperty("ok",true);
            try{response.add("data",handle(request));}
            catch(Exception ex){response.addProperty("ok",false);response.addProperty("error",safe(ex.getMessage()));}
            out.println(gson.toJson(response));
        }catch(Exception ex){System.err.println("Solicitud cliente-servidor: "+ex.getMessage());}
    }

    private com.google.gson.JsonElement handle(JsonObject q)throws Exception{
        String action=q.has("action")?q.get("action").getAsString():"";
        switch(action){
            case "PING": {JsonObject pong=new JsonObject();pong.addProperty("message","Conexión JHEYVX TECH estable");return pong;}
            case "SUMMARY": return gson.toJsonTree(inventory.summary());
            case "PRODUCTS": return gson.toJsonTree(inventory.list(q.has("search")?q.get("search").getAsString():""));
            case "SAVE_PRODUCT": {Product p=gson.fromJson(q.getAsJsonObject("payload"),Product.class);return gson.toJsonTree(inventory.save(p));}
            case "DELETE_PRODUCT": inventory.delete(q.get("id").getAsLong());return new JsonObject();
            case "SALES": return gson.toJsonTree(sales.latest(q.has("limit")?q.get("limit").getAsInt():50));
            case "CHECKOUT": {JsonObject p=q.getAsJsonObject("payload");return gson.toJsonTree(sales.checkout(p.get("productId").getAsLong(),p.get("quantity").getAsInt()));}
            default: throw new IllegalArgumentException("Operación de red desconocida.");
        }
    }

    private static String safe(String message){return message==null||message.trim().isEmpty()?"Ocurrió un error al procesar la solicitud.":message;}

    @Override public synchronized void close(){
        running.set(false);try{if(listener!=null)listener.close();}catch(Exception ignored){}workers.shutdownNow();
    }
}
