package pe.jheyvx.tech.ui;

import pe.jheyvx.tech.network.ApiClient;
import pe.jheyvx.tech.network.ApiServer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class MainFrame extends JFrame {
    private final ApiClient api;
    private final ApiServer server;
    private final CardLayout cards=new CardLayout();
    private final JPanel pages=new JPanel(cards);
    private final JLabel sectionTitle=new JLabel("Resumen");
    private final JLabel connection=new JLabel("●  SERVIDOR LOCAL ACTIVO");
    private final DashboardPanel dashboard;
    private final InventoryPanel inventory;
    private final SalesPanel sales;

    public MainFrame(ApiClient api,ApiServer server){
        super("JHEYVX TECH · Control de inventario");this.api=api;this.server=server;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);setMinimumSize(new Dimension(1040,700));setSize(1260,820);setLocationRelativeTo(null);getContentPane().setBackground(Ui.BG);setLayout(new BorderLayout());
        dashboard=new DashboardPanel(api,new Runnable(){public void run(){show("inventory");}});
        inventory=new InventoryPanel(api,new Runnable(){public void run(){dashboard.refresh();}});
        sales=new SalesPanel(api,new Runnable(){public void run(){dashboard.refresh();inventory.refresh();}});
        pages.setBackground(Ui.BG);pages.add(dashboard,"dashboard");pages.add(inventory,"inventory");pages.add(sales,"sales");
        add(sidebar(),BorderLayout.WEST);add(mainArea(),BorderLayout.CENTER);show("dashboard");
    }

    private JPanel sidebar(){
        JPanel side=new JPanel(new BorderLayout());side.setPreferredSize(new Dimension(224,0));side.setBackground(new java.awt.Color(11,17,21));side.setBorder(BorderFactory.createMatteBorder(0,0,0,1,Ui.LINE));
        JPanel upper=new JPanel(new BorderLayout());upper.setOpaque(false);upper.setBorder(BorderFactory.createEmptyBorder(24,17,19,14));
        JLabel brand=new JLabel("<html><span style='color:#18D3E2;font-size:19px;font-weight:700'>JHEYVX</span> <span style='color:#EAF2F1;font-size:19px;font-weight:700'>TECH</span><br><span style='color:#81969B;font-size:9px;letter-spacing:2px'>DESKTOP MANAGEMENT</span></html>");upper.add(brand,BorderLayout.CENTER);
        JPanel nav=new JPanel(new GridBagLayout());nav.setOpaque(false);nav.setBorder(BorderFactory.createEmptyBorder(6,12,0,12));GridBagConstraints g=new GridBagConstraints();g.gridx=0;g.fill=GridBagConstraints.HORIZONTAL;g.weightx=1;g.insets=new Insets(4,0,5,0);
        addNav(nav,g,"⌂","Resumen","dashboard",0);addNav(nav,g,"▦","Inventario","inventory",1);addNav(nav,g,"↗","Ventas","sales",2);
        JPanel bottom=new JPanel(new BorderLayout(0,8));bottom.setOpaque(false);bottom.setBorder(BorderFactory.createEmptyBorder(15,17,19,17));
        JLabel profile=new JLabel("<html><span style='color:#18D3E2;font-weight:bold'>JV</span> &nbsp; Jheyssun Vargas<br><span style='color:#81969B;font-size:10px'>PROYECTO ACADÉMICO · 2026</span></html>");profile.setBorder(BorderFactory.createMatteBorder(1,0,0,0,Ui.LINE));profile.setBorder(BorderFactory.createCompoundBorder(profile.getBorder(),BorderFactory.createEmptyBorder(13,3,3,0)));bottom.add(profile,BorderLayout.CENTER);
        side.add(upper,BorderLayout.NORTH);side.add(nav,BorderLayout.CENTER);side.add(bottom,BorderLayout.SOUTH);return side;
    }

    private void addNav(JPanel nav,GridBagConstraints g,String icon,String label,final String page,int row){
        final JButton b=new JButton("  "+icon+"     "+label);b.setHorizontalAlignment(SwingConstants.LEFT);b.setFont(Ui.strong(13));b.setForeground(Ui.MUTED);b.setBackground(new java.awt.Color(11,17,21));b.setBorder(BorderFactory.createEmptyBorder(12,13,12,10));b.setFocusPainted(false);b.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));b.addActionListener(e->show(page));g.gridy=row;nav.add(b,g);
    }

    private JPanel mainArea(){
        JPanel main=new JPanel(new BorderLayout());main.setBackground(Ui.BG);
        JPanel top=new JPanel(new BorderLayout());top.setBackground(Ui.BG);top.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,0,1,0,Ui.LINE),BorderFactory.createEmptyBorder(15,25,15,25)));
        sectionTitle.setFont(Ui.strong(13));sectionTitle.setForeground(Ui.TEXT);JLabel crumb=new JLabel("JHEYVX TECH   /   DESARROLLO DE APLICACIONES I");crumb.setFont(new java.awt.Font("Consolas",0,10));crumb.setForeground(Ui.MUTED);
        JPanel left=new JPanel(new BorderLayout(0,5));left.setOpaque(false);left.add(crumb,BorderLayout.NORTH);left.add(sectionTitle,BorderLayout.CENTER);
        connection.setFont(new java.awt.Font("Consolas",0,10));connection.setForeground(Ui.GREEN);connection.setHorizontalAlignment(SwingConstants.RIGHT);top.add(left,BorderLayout.WEST);top.add(connection,BorderLayout.EAST);
        main.add(top,BorderLayout.NORTH);main.add(pages,BorderLayout.CENTER);return main;
    }

    private void show(String page){
        cards.show(pages,page);String title="Resumen";if("inventory".equals(page)){title="Inventario";inventory.refresh();}if("sales".equals(page)){title="Ventas";sales.refresh();}if("dashboard".equals(page))dashboard.refresh();sectionTitle.setText(title);
    }
}
