package pe.jheyvx.tech.model;

import java.math.BigDecimal;

public class Product {
    public long id;
    public String sku = "";
    public String name = "";
    public String category = "";
    public String description = "";
    public BigDecimal price = BigDecimal.ZERO;
    public int stock;
    public int minStock = 3;
    public boolean active = true;

    public Product() { }

    public boolean isLowStock() { return stock <= minStock; }
}
