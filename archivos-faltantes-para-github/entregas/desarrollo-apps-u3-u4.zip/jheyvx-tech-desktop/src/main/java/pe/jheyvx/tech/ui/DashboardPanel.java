package pe.jheyvx.tech.ui;

import com.google.gson.JsonObject;
import pe.jheyvx.tech.network.ApiClient;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.GridLayout;
import java.awt.Image;
import javax.imageio.ImageIO;

public class DashboardPanel extends JPanel {
    private final ApiClient api;private final Runnable openInventory;private final JLabel productCount=valueLabel("—"),units=valueLabel("—"),low=valueLabel("—"),stockValue=valueLabel("—"),sales=valueLabel("—"),status=new JLabel("Conectando con el servicio local...");
    public DashboardPanel(ApiClient api,Runnable openInventory){this.api=api;this.openInventory=openInventory;setLayout(new BorderLayout(0,17));setBackground(Ui.BG);setBorder(BorderFactory.createEmptyBorder(23,27,24,27));add(hero(),BorderLayout.NORTH);JPanel center=new JPanel(new BorderLayout(0,13));center.setOpaque(false);center.add(metrics(),BorderLayout.NORTH);center.add(highlights(),BorderLayout.CENTER);add(center,BorderLayout.CENTER);refresh();}
    private JPanel hero(){
        Hero hero=new Hero();hero.setLayout(new BorderLayout());hero.setPreferredSize(new Dimension(0,208));hero.setBorder(BorderFactory.createEmptyBorder(24,27,24,25));
        JPanel words=new JPanel(new BorderLayout(0,9));words.setOpaque(false);JLabel eyebrow=new JLabel("CONTROL DE INVENTARIO  ·  EST. 2026");eyebrow.setFont(new Font("Consolas",0,10));eyebrow.setForeground(Ui.CYAN);JLabel h=new JLabel("Tu tienda. En orden.");h.setFont(Ui.strong(31));h.setForeground(Ui.TEXT);JLabel desc=new JLabel("Productos, existencias y ventas en un solo espacio.");desc.setFont(Ui.font(13));desc.setForeground(new Color(181,200,202));JPanel txt=new JPanel(new BorderLayout(0,7));txt.setOpaque(false);txt.add(eyebrow,BorderLayout.NORTH);txt.add(h,BorderLayout.CENTER);txt.add(desc,BorderLayout.SOUTH);words.add(txt,BorderLayout.CENTER);
        JButton action=new JButton("＋  AGREGAR PRODUCTO");Ui.styleButton(action,true);action.addActionListener(e->openInventory.run());words.add(action,BorderLayout.SOUTH);hero.add(words,BorderLayout.WEST);return hero;
    }
    private JPanel metrics(){JPanel row=new JPanel(new GridLayout(1,4,11,0));row.setOpaque(false);row.add(metric("REFERENCIAS","Productos activos",productCount,Ui.CYAN));row.add(metric("UNIDADES","En almacén",units,Ui.TEXT));row.add(metric("POR REPONER","Bajo el mínimo",low,Ui.AMBER));row.add(metric("VALOR EN STOCK","Costo de inventario",stockValue,Ui.TEXT));return row;}
    private JPanel metric(String label,String sub,JLabel value,Color tint){JPanel p=new JPanel(new BorderLayout(0,10));Ui.surface(p);JLabel l=new JLabel(label);l.setFont(new Font("Consolas",0,9));l.setForeground(Ui.MUTED);value.setForeground(tint);JLabel s=new JLabel(sub);s.setFont(Ui.font(10));s.setForeground(Ui.MUTED);p.add(l,BorderLayout.NORTH);p.add(value,BorderLayout.CENTER);p.add(s,BorderLayout.SOUTH);return p;}
    private JPanel highlights(){JPanel grid=new JPanel(new GridLayout(1,2,11,0));grid.setOpaque(false);JPanel activity=new JPanel(new BorderLayout(0,9));Ui.surface(activity);activity.add(label("MOVIMIENTO DE HOY","Hoy en JHEYVX TECH"),BorderLayout.NORTH);JPanel total=new JPanel(new BorderLayout(0,3));total.setOpaque(false);sales.setFont(Ui.strong(30));sales.setForeground(Ui.CYAN);JLabel note=new JLabel("Ventas confirmadas · monto del día");note.setFont(Ui.font(11));note.setForeground(Ui.MUTED);total.add(sales,BorderLayout.CENTER);total.add(note,BorderLayout.SOUTH);activity.add(total,BorderLayout.CENTER);activity.add(status,BorderLayout.SOUTH);
        JPanel tip=new JPanel(new BorderLayout(0,9));Ui.surface(tip);tip.add(label("REGLA DE OPERACIÓN","Venta protegida por transacción"),BorderLayout.NORTH);JLabel info=new JLabel("<html><div style='width:240px'>La venta revisa existencias, guarda el detalle y descuenta el stock como una sola operación JDBC. Si falla, no altera el inventario.</div></html>");info.setFont(Ui.font(12));info.setForeground(new Color(181,200,202));tip.add(info,BorderLayout.CENTER);grid.add(activity);grid.add(tip);return grid;}
    private JPanel label(String tag,String title){JPanel p=new JPanel(new BorderLayout(0,5));p.setOpaque(false);JLabel a=new JLabel(tag);a.setFont(new Font("Consolas",0,9));a.setForeground(Ui.CYAN);JLabel b=new JLabel(title);b.setFont(Ui.strong(15));b.setForeground(Ui.TEXT);p.add(a,BorderLayout.NORTH);p.add(b,BorderLayout.SOUTH);return p;}
    private static JLabel valueLabel(String value){JLabel l=new JLabel(value);l.setFont(Ui.strong(24));return l;}
    public void refresh(){new SwingWorker<JsonObject,Void>(){protected JsonObject doInBackground(){return api.call("SUMMARY").getAsJsonObject();}protected void done(){try{JsonObject s=get();productCount.setText(s.get("products").getAsString());units.setText(s.get("units").getAsString());low.setText(s.get("lowStock").getAsString());stockValue.setText(money(s.get("stockValue").getAsString()));sales.setText(money(s.get("todaySales").getAsString()));status.setText("JDBC · H2 RELACIONAL · CLIENTE TCP ACTIVO");status.setForeground(Ui.GREEN);}catch(Exception ex){status.setText("Servidor sin respuesta: "+root(ex));status.setForeground(Ui.RED);}}}.execute();}
    private static String money(String value){try{return "S/ "+new java.text.DecimalFormat("#,##0.00").format(new java.math.BigDecimal(value));}catch(Exception ex){return "S/ 0.00";}}
    private static String root(Exception e){Throwable t=e;while(t.getCause()!=null)t=t.getCause();return t.getMessage();}
    private static class Hero extends JPanel{
        private Image wallpaper;Hero(){setBackground(Ui.PANEL);try{wallpaper=ImageIO.read(getClass().getResource("/assets/aura-cyan.png"));}catch(Exception ignored){}setOpaque(false);}
        protected void paintComponent(Graphics g){Graphics2D g2=(Graphics2D)g.create();g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g2.setColor(new Color(14,24,29));g2.fillRoundRect(0,0,getWidth(),getHeight(),15,15);if(wallpaper!=null){g2.setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_OVER,.21f));g2.drawImage(wallpaper,getWidth()-330,-120,360,490,null);g2.setComposite(java.awt.AlphaComposite.SrcOver);}g2.setColor(new Color(24,211,226,50));g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,15,15);g2.dispose();super.paintComponent(g);}
    }
}
