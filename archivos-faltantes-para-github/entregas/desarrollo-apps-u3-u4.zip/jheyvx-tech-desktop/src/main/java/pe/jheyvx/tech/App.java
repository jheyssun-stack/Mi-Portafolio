package pe.jheyvx.tech;

import com.formdev.flatlaf.FlatDarkLaf;
import pe.jheyvx.tech.db.Database;
import pe.jheyvx.tech.network.ApiClient;
import pe.jheyvx.tech.network.ApiServer;
import pe.jheyvx.tech.ui.MainFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public final class App {
    private App() { }
    public static void main(String[] args) throws Exception {
        boolean serverOnly=false,clientOnly=false;
        for(String arg:args){if("--server".equalsIgnoreCase(arg))serverOnly=true;if("--client".equalsIgnoreCase(arg))clientOnly=true;}
        String host=System.getenv("JHEYVX_SERVER_HOST");if(host==null||host.trim().isEmpty())host="127.0.0.1";
        int port=8765;String portEnv=System.getenv("JHEYVX_SERVER_PORT");if(portEnv!=null&&!portEnv.trim().isEmpty())port=Integer.parseInt(portEnv);
        final ApiServer localServer;
        if(!clientOnly){Database.initialize();String bind=System.getenv("JHEYVX_BIND_HOST");if(bind==null||bind.trim().isEmpty())bind="127.0.0.1";localServer=new ApiServer(bind,port);localServer.start();}
        else localServer=null;
        final ApiClient client=new ApiClient(host,port);
        if(serverOnly){System.out.println("JHEYVX TECH servidor escuchando en "+port+". Ctrl+C para cerrar.");Runtime.getRuntime().addShutdownHook(new Thread(new Runnable(){public void run(){localServer.close();}}));while(true)Thread.sleep(60000);}
        try{UIManager.setLookAndFeel(new FlatDarkLaf());}catch(Exception ex){System.err.println("Se usará el estilo Swing integrado: "+ex.getMessage());}
        UIManager.put("Component.arc",10);UIManager.put("Button.arc",10);UIManager.put("TextComponent.arc",8);UIManager.put("Component.focusColor",new java.awt.Color(25,214,229));
        SwingUtilities.invokeLater(new Runnable(){public void run(){new MainFrame(client,localServer).setVisible(true);}});
    }
}
