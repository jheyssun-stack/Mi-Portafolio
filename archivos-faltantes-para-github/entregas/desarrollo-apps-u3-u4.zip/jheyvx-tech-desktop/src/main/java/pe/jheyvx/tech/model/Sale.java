package pe.jheyvx.tech.model;

import java.math.BigDecimal;

public class Sale {
    public long id;
    public String code;
    public BigDecimal total;
    public String createdAt;

    public Sale() { }
    public Sale(long id, String code, BigDecimal total, String createdAt) { this.id=id; this.code=code; this.total=total; this.createdAt=createdAt; }
}
