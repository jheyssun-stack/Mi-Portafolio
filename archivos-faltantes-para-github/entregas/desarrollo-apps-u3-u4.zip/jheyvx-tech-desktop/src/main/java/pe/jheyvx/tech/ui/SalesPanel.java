package pe.jheyvx.tech.ui;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import pe.jheyvx.tech.model.Product;
import pe.jheyvx.tech.model.Sale;
import pe.jheyvx.tech.network.ApiClient;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingWorker;
import javax.swing.table.AbstractTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class SalesPanel extends JPanel {
    private final ApiClient api;private final Runnable changed;private final JComboBox<Product> product=new JComboBox<Product>();private final JSpinner quantity=new JSpinner(new SpinnerNumberModel(1,1,999,1));private final JLabel stockHint=new JLabel("Selecciona un producto para ver sus existencias.");private final JLabel status=new JLabel("Las ventas son de demostración; no se procesa pago real.");private final JTable table=new JTable(new SalesModel());private final SalesModel model=(SalesModel)table.getModel();
    public SalesPanel(ApiClient api,Runnable changed){this.api=api;this.changed=changed;setLayout(new BorderLayout(0,14));setBackground(Ui.BG);setBorder(BorderFactory.createEmptyBorder(23,27,24,27));add(header(),BorderLayout.NORTH);add(body(),BorderLayout.CENTER);product.addActionListener(e->updateHint());refresh();}
    private JPanel header(){JPanel p=new JPanel(new BorderLayout(0,5));p.setOpaque(false);JLabel tag=new JLabel("VENTAS  /  TRANSACCIONES JDBC");tag.setFont(new java.awt.Font("Consolas",0,10));tag.setForeground(Ui.CYAN);JLabel title=new JLabel("Punto de venta");title.setFont(Ui.strong(25));title.setForeground(Ui.TEXT);JLabel desc=new JLabel("Cada operación registra el detalle y actualiza el stock con rollback si ocurre un error.");desc.setFont(Ui.font(12));desc.setForeground(Ui.MUTED);JPanel sub=new JPanel(new BorderLayout(0,4));sub.setOpaque(false);sub.add(title,BorderLayout.NORTH);sub.add(desc,BorderLayout.CENTER);p.add(tag,BorderLayout.NORTH);p.add(sub,BorderLayout.CENTER);return p;}
    private JPanel body(){JPanel wrap=new JPanel(new GridLayout(1,2,12,0));wrap.setOpaque(false);JPanel newSale=new JPanel(new BorderLayout(0,15));Ui.surface(newSale);JPanel heading=new JPanel(new BorderLayout(0,4));heading.setOpaque(false);heading.add(title("NUEVA OPERACIÓN","Registrar venta"),BorderLayout.NORTH);JLabel msg=new JLabel("Elige el producto y la cantidad a descontar.");msg.setFont(Ui.font(11));msg.setForeground(Ui.MUTED);heading.add(msg,BorderLayout.SOUTH);newSale.add(heading,BorderLayout.NORTH);
        JPanel fields=new JPanel(new GridLayout(0,1,0,10));fields.setOpaque(false);JPanel pl=fieldLabel("PRODUCTO");product.setFont(Ui.font(12));product.setBackground(Ui.PANEL_ALT);product.setForeground(Ui.TEXT);fields.add(pl);fields.add(product);JPanel q=fieldLabel("CANTIDAD");quantity.setFont(Ui.font(13));fields.add(q);fields.add(quantity);stockHint.setFont(Ui.font(11));stockHint.setForeground(Ui.CYAN);fields.add(stockHint);newSale.add(fields,BorderLayout.CENTER);
        JPanel bottom=new JPanel(new BorderLayout(0,8));bottom.setOpaque(false);JButton confirm=new JButton("CONFIRMAR VENTA  →");Ui.styleButton(confirm,true);confirm.addActionListener(e->checkout());status.setFont(Ui.font(10));status.setForeground(Ui.MUTED);bottom.add(confirm,BorderLayout.NORTH);bottom.add(status,BorderLayout.SOUTH);newSale.add(bottom,BorderLayout.SOUTH);
        JPanel history=new JPanel(new BorderLayout(0,10));Ui.surface(history);history.add(title("HISTORIAL","Últimas ventas"),BorderLayout.NORTH);table.setFillsViewportHeight(true);table.setRowHeight(38);table.setFont(Ui.font(11));table.setForeground(Ui.TEXT);table.setBackground(Ui.PANEL);table.setGridColor(Ui.LINE);table.setShowVerticalLines(false);table.getTableHeader().setFont(new java.awt.Font("Consolas",0,9));table.getTableHeader().setForeground(Ui.MUTED);table.getTableHeader().setBackground(Ui.PANEL_ALT);JScrollPane scroll=new JScrollPane(table);scroll.setBorder(BorderFactory.createLineBorder(Ui.LINE));scroll.getViewport().setBackground(Ui.PANEL);history.add(scroll,BorderLayout.CENTER);wrap.add(newSale);wrap.add(history);return wrap;}
    private JPanel title(String top,String name){JPanel p=new JPanel(new BorderLayout(0,5));p.setOpaque(false);JLabel a=new JLabel(top);a.setFont(new java.awt.Font("Consolas",0,9));a.setForeground(Ui.CYAN);JLabel b=new JLabel(name);b.setFont(Ui.strong(16));b.setForeground(Ui.TEXT);p.add(a,BorderLayout.NORTH);p.add(b,BorderLayout.CENTER);return p;}
    private JPanel fieldLabel(String name){JPanel p=new JPanel(new BorderLayout());p.setOpaque(false);JLabel l=new JLabel(name);l.setFont(new java.awt.Font("Consolas",0,9));l.setForeground(Ui.MUTED);p.add(l,BorderLayout.CENTER);return p;}
    private void updateHint(){Product p=(Product)product.getSelectedItem();stockHint.setText(p==null?"No hay productos disponibles.":"Existencias disponibles: "+p.stock+"  ·  Precio: S/ "+p.price.toPlainString());if(p!=null)((SpinnerNumberModel)quantity.getModel()).setMaximum(Math.max(1,p.stock));}
    public void refresh(){new SwingWorker<Object[],Void>(){protected Object[] doInBackground(){JsonArray products=api.call("PRODUCTS").getAsJsonArray();JsonArray sales=api.call("SALES").getAsJsonArray();Gson g=new Gson();List<Product> ps=new ArrayList<Product>();for(JsonElement e:products)ps.add(g.fromJson(e,Product.class));List<Sale> ss=new ArrayList<Sale>();for(JsonElement e:sales)ss.add(g.fromJson(e,Sale.class));return new Object[]{ps,ss};}protected void done(){try{Object[] data=get();@SuppressWarnings("unchecked")List<Product> ps=(List<Product>)data[0];@SuppressWarnings("unchecked")List<Sale> ss=(List<Sale>)data[1];Product selected=(Product)product.getSelectedItem();product.removeAllItems();for(Product p:ps)product.addItem(p);if(selected!=null)for(int i=0;i<product.getItemCount();i++)if(product.getItemAt(i).id==selected.id)product.setSelectedIndex(i);model.set(ss);updateHint();}catch(Exception ex){status.setText(root(ex));status.setForeground(Ui.RED);}}}.execute();}
    private void checkout(){Product p=(Product)product.getSelectedItem();if(p==null){status.setText("No hay productos disponibles.");status.setForeground(Ui.RED);return;}final int qty=((Number)quantity.getValue()).intValue();if(qty>p.stock){status.setText("No alcanza el stock disponible.");status.setForeground(Ui.RED);return;}int confirm=JOptionPane.showConfirmDialog(this,"Registrar "+qty+" × "+p.name+" por S/ "+p.price.multiply(BigDecimal.valueOf(qty)).setScale(2,BigDecimal.ROUND_HALF_UP)+"?","Confirmar venta",JOptionPane.OK_CANCEL_OPTION);if(confirm!=JOptionPane.OK_OPTION)return;JsonObject body=new JsonObject();body.addProperty("productId",p.id);body.addProperty("quantity",qty);new SwingWorker<JsonElement,Void>(){protected JsonElement doInBackground(){return api.call("CHECKOUT",body);}protected void done(){try{JsonObject r=get().getAsJsonObject();status.setText("Venta "+r.get("code").getAsString()+" confirmada; stock actualizado.");status.setForeground(Ui.GREEN);quantity.setValue(1);refresh();changed.run();}catch(Exception ex){status.setText(root(ex));status.setForeground(Ui.RED);}}}.execute();}
    private static String root(Exception e){Throwable t=e;while(t.getCause()!=null)t=t.getCause();return t.getMessage();}
    private static class SalesModel extends AbstractTableModel{private final String[] cols={"CÓDIGO","FECHA","TOTAL"};private List<Sale> rows=new ArrayList<Sale>();void set(List<Sale> r){rows=r;fireTableDataChanged();}public int getRowCount(){return rows.size();}public int getColumnCount(){return cols.length;}public String getColumnName(int c){return cols[c];}public Object getValueAt(int r,int c){Sale s=rows.get(r);if(c==0)return s.code;if(c==1){try{return new SimpleDateFormat("dd/MM · HH:mm").format(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(s.createdAt));}catch(Exception ex){return "—";}}return "S/ "+s.total.setScale(2,BigDecimal.ROUND_HALF_UP).toPlainString();}}
}
