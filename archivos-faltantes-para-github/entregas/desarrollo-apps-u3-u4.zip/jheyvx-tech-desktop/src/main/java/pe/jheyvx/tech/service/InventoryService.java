package pe.jheyvx.tech.service;

import pe.jheyvx.tech.db.Database;
import pe.jheyvx.tech.model.Product;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** JDBC CRUD for the desktop inventory module. */
public class InventoryService {
    public List<Product> list(String search) throws SQLException {
        String term = search == null ? "" : search.trim().toLowerCase();
        String sql = "SELECT * FROM products WHERE active=TRUE AND (LOWER(sku) LIKE ? OR LOWER(name) LIKE ? OR LOWER(category) LIKE ?) ORDER BY name";
        List<Product> rows = new ArrayList<Product>();
        try (Connection c=Database.open(); PreparedStatement s=c.prepareStatement(sql)) {
            String pattern="%"+term+"%"; s.setString(1,pattern); s.setString(2,pattern); s.setString(3,pattern);
            try (ResultSet r=s.executeQuery()) { while(r.next()) rows.add(read(r)); }
        }
        return rows;
    }

    public Product save(Product p) throws SQLException {
        validate(p);
        try (Connection c=Database.open()) {
            c.setAutoCommit(false);
            try {
                if (p.id<=0) {
                    String q="INSERT INTO products(sku,name,category,description,price,stock,min_stock,active) VALUES(?,?,?,?,?,?,?,TRUE)";
                    try(PreparedStatement s=c.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)) {
                        bind(s,p); s.executeUpdate(); try(ResultSet keys=s.getGeneratedKeys()){ if(keys.next()) p.id=keys.getLong(1); }
                    }
                } else {
                    String q="UPDATE products SET sku=?,name=?,category=?,description=?,price=?,stock=?,min_stock=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND active=TRUE";
                    try(PreparedStatement s=c.prepareStatement(q)){bind(s,p);s.setLong(8,p.id);if(s.executeUpdate()!=1)throw new IllegalArgumentException("No se encontró el producto para editar.");}
                }
                c.commit(); return p;
            } catch(SQLException ex){c.rollback();throw ex;} catch(RuntimeException ex){c.rollback();throw ex;}
            finally{c.setAutoCommit(true);}
        }
    }

    public void delete(long id) throws SQLException {
        try(Connection c=Database.open();PreparedStatement s=c.prepareStatement("UPDATE products SET active=FALSE,updated_at=CURRENT_TIMESTAMP WHERE id=? AND active=TRUE")){
            s.setLong(1,id);if(s.executeUpdate()!=1)throw new IllegalArgumentException("El producto ya no existe.");
        }
    }

    public Map<String,Object> summary() throws SQLException {
        Map<String,Object> result=new LinkedHashMap<String,Object>();
        String sql="SELECT COUNT(*) products, COALESCE(SUM(stock),0) units, COALESCE(SUM(price*stock),0) stock_value, SUM(CASE WHEN stock<=min_stock THEN 1 ELSE 0 END) low_stock FROM products WHERE active=TRUE";
        try(Connection c=Database.open();Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){
            r.next();result.put("products",r.getInt("products"));result.put("units",r.getInt("units"));result.put("stockValue",r.getBigDecimal("stock_value"));result.put("lowStock",r.getInt("low_stock"));
        }
        try(Connection c=Database.open();PreparedStatement s=c.prepareStatement("SELECT COALESCE(SUM(total),0) FROM sales WHERE CAST(created_at AS DATE)=CURRENT_DATE");ResultSet r=s.executeQuery()){
            r.next();result.put("todaySales",r.getBigDecimal(1));
        }
        return result;
    }

    private static Product read(ResultSet r)throws SQLException{
        Product p=new Product();p.id=r.getLong("id");p.sku=r.getString("sku");p.name=r.getString("name");p.category=r.getString("category");p.description=r.getString("description");p.price=r.getBigDecimal("price");p.stock=r.getInt("stock");p.minStock=r.getInt("min_stock");p.active=r.getBoolean("active");return p;
    }
    private static void bind(PreparedStatement s,Product p)throws SQLException{
        s.setString(1,p.sku.trim().toUpperCase());s.setString(2,p.name.trim());s.setString(3,p.category.trim());s.setString(4,p.description==null?"":p.description.trim());s.setBigDecimal(5,p.price);s.setInt(6,p.stock);s.setInt(7,p.minStock);
    }
    public static void validate(Product p){
        if(p==null)throw new IllegalArgumentException("Completa los datos del producto.");
        if(p.sku==null||p.sku.trim().isEmpty()||p.sku.trim().length()>40)throw new IllegalArgumentException("El código SKU es obligatorio (máximo 40 caracteres).");
        if(p.name==null||p.name.trim().isEmpty()||p.name.trim().length()>120)throw new IllegalArgumentException("El nombre es obligatorio (máximo 120 caracteres).");
        if(p.category==null||p.category.trim().isEmpty()||p.category.trim().length()>70)throw new IllegalArgumentException("Indica una categoría de hasta 70 caracteres.");
        if(p.description!=null&&p.description.length()>500)throw new IllegalArgumentException("La descripción no puede exceder 500 caracteres.");
        if(p.price==null||p.price.compareTo(BigDecimal.ZERO)<0)throw new IllegalArgumentException("El precio debe ser mayor o igual a cero.");
        if(p.stock<0)throw new IllegalArgumentException("El stock no puede ser negativo.");
        if(p.minStock<0)throw new IllegalArgumentException("El mínimo de stock no puede ser negativo.");
    }
}
