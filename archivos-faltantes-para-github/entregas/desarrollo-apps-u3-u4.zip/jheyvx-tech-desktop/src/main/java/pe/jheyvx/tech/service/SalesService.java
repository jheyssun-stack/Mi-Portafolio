package pe.jheyvx.tech.service;

import pe.jheyvx.tech.db.Database;
import pe.jheyvx.tech.model.Sale;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Each sale and stock reduction is committed or rolled back as one transaction. */
public class SalesService {
    public Sale checkout(long productId,int quantity)throws SQLException{
        if(productId<=0)throw new IllegalArgumentException("Selecciona un producto.");
        if(quantity<1)throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        try(Connection c=Database.open()){
            c.setAutoCommit(false);
            try{
                String name;BigDecimal price;int stock;
                try(PreparedStatement s=c.prepareStatement("SELECT name,price,stock FROM products WHERE id=? AND active=TRUE FOR UPDATE")){
                    s.setLong(1,productId);try(ResultSet r=s.executeQuery()){if(!r.next())throw new IllegalArgumentException("El producto ya no está disponible.");name=r.getString(1);price=r.getBigDecimal(2);stock=r.getInt(3);}
                }
                if(stock<quantity)throw new IllegalArgumentException("Stock insuficiente: quedan "+stock+" unidades.");
                BigDecimal total=price.multiply(BigDecimal.valueOf(quantity)).setScale(2,BigDecimal.ROUND_HALF_UP);
                String code="JVT-"+System.currentTimeMillis();long saleId;
                try(PreparedStatement s=c.prepareStatement("INSERT INTO sales(sale_code,total) VALUES(?,?)",Statement.RETURN_GENERATED_KEYS)){
                    s.setString(1,code);s.setBigDecimal(2,total);s.executeUpdate();try(ResultSet k=s.getGeneratedKeys()){if(!k.next())throw new SQLException("No se pudo generar el código de venta.");saleId=k.getLong(1);}
                }
                try(PreparedStatement s=c.prepareStatement("INSERT INTO sale_items(sale_id,product_id,product_name,unit_price,quantity,subtotal) VALUES(?,?,?,?,?,?)")){
                    s.setLong(1,saleId);s.setLong(2,productId);s.setString(3,name);s.setBigDecimal(4,price);s.setInt(5,quantity);s.setBigDecimal(6,total);s.executeUpdate();
                }
                try(PreparedStatement s=c.prepareStatement("UPDATE products SET stock=stock-?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND stock>=?")){
                    s.setInt(1,quantity);s.setLong(2,productId);s.setInt(3,quantity);if(s.executeUpdate()!=1)throw new SQLException("El inventario cambió; vuelve a intentar la venta.");
                }
                c.commit();return new Sale(saleId,code,total,null);
            }catch(SQLException ex){c.rollback();throw ex;}catch(RuntimeException ex){c.rollback();throw ex;}
            finally{c.setAutoCommit(true);}
        }
    }

    public List<Sale> latest(int limit)throws SQLException{
        List<Sale> rows=new ArrayList<Sale>();
        try(Connection c=Database.open();PreparedStatement s=c.prepareStatement("SELECT id,sale_code,total,created_at FROM sales ORDER BY created_at DESC LIMIT ?")){
            s.setInt(1,Math.max(1,Math.min(100,limit)));try(ResultSet r=s.executeQuery()){while(r.next())rows.add(new Sale(r.getLong(1),r.getString(2),r.getBigDecimal(3),r.getTimestamp(4).toString()));}
        }return rows;
    }
}
