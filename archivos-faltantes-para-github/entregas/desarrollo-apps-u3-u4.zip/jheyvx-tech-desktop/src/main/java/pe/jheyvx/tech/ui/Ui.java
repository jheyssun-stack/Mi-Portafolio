package pe.jheyvx.tech.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;

public final class Ui {
    public static final Color BG=new Color(9,14,18), PANEL=new Color(16,24,30), PANEL_ALT=new Color(20,30,36), LINE=new Color(37,54,61), TEXT=new Color(234,242,241), MUTED=new Color(137,157,163), CYAN=new Color(24,211,226), CYAN_DARK=new Color(13,66,73), AMBER=new Color(238,183,104), RED=new Color(241,119,113), GREEN=new Color(103,207,154);
    private Ui(){}
    public static Font font(int size){return new Font("Segoe UI",Font.PLAIN,size);}
    public static Font strong(int size){return new Font("Segoe UI Semibold",Font.BOLD,size);}
    public static void styleButton(JButton b,boolean primary){b.setFont(strong(12));b.setFocusPainted(false);b.setForeground(primary?new Color(5,28,31):TEXT);b.setBackground(primary?CYAN:new Color(29,42,48));b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(primary?CYAN:LINE),BorderFactory.createEmptyBorder(9,14,9,14)));b.setMargin(new Insets(6,12,6,12));b.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));}
    public static void surface(JComponent c){c.setBackground(PANEL);c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(LINE),BorderFactory.createEmptyBorder(16,18,16,18)));}
}
