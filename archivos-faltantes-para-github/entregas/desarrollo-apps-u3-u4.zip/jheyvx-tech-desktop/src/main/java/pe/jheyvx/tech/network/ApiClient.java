package pe.jheyvx.tech.network;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Synchronous client used only from SwingWorker background tasks. */
public class ApiClient {
    private final String host;private final int port;private final Gson gson=new Gson();
    public ApiClient(String host,int port){this.host=host;this.port=port;}
    public JsonElement call(String action){return call(action,new JsonObject());}
    public JsonElement call(String action,JsonObject payload){
        JsonObject request=new JsonObject();request.addProperty("action",action);request.add("payload",payload);
        try(Socket socket=new Socket()){
            socket.connect(new InetSocketAddress(host,port),2500);socket.setSoTimeout(10000);
            try(PrintWriter out=new PrintWriter(socket.getOutputStream(),true);BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8))){
                out.println(gson.toJson(request));String line=in.readLine();if(line==null)throw new IllegalStateException("El servidor cerró la conexión.");
                JsonObject response=JsonParser.parseString(line).getAsJsonObject();if(!response.get("ok").getAsBoolean())throw new IllegalStateException(response.get("error").getAsString());
                return response.get("data");
            }
        }catch(IllegalStateException ex){throw ex;}catch(Exception ex){throw new IllegalStateException("No se pudo conectar con el servidor local. "+ex.getMessage(),ex);}
    }
    public String host(){return host;}public int port(){return port;}
}
