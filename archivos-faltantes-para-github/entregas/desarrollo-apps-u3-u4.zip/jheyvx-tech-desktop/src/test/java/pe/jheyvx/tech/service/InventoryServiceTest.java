package pe.jheyvx.tech.service;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pe.jheyvx.tech.db.Database;
import pe.jheyvx.tech.model.Product;
import pe.jheyvx.tech.model.Sale;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InventoryServiceTest {
    private static final InventoryService inventory=new InventoryService();
    private static final SalesService sales=new SalesService();

    @BeforeAll static void setup() throws Exception {System.setProperty("jheyvx.db.url","jdbc:h2:mem:jheyvx-tests;DB_CLOSE_DELAY=-1");Database.initialize();}
    @BeforeEach void clean() throws Exception {try(Connection c=Database.open();Statement s=c.createStatement()){s.execute("DELETE FROM sales");s.execute("DELETE FROM products");}}

    @Test void productCrudAndSearchStayInTheRelationalTable() throws Exception {
        Product p=product("TEST-1","Teclado de prueba",3);inventory.save(p);assertTrue(p.id>0);assertEquals(1,inventory.list("teclado").size());
        p.name="Teclado actualizado";p.stock=8;inventory.save(p);assertEquals("Teclado actualizado",inventory.list("actualizado").get(0).name);
        inventory.delete(p.id);assertTrue(inventory.list("").isEmpty());
    }

    @Test void validationRejectsNegativeStockAndPrice() {
        Product p=product("TEST-2","Producto inválido",2);p.stock=-1;assertThrows(IllegalArgumentException.class,()->InventoryService.validate(p));
        p.stock=0;p.price=new BigDecimal("-0.01");assertThrows(IllegalArgumentException.class,()->InventoryService.validate(p));
    }

    @Test void checkoutUpdatesStockAndRecordsSaleAtomically() throws Exception {
        Product p=product("TEST-3","Mouse de prueba",5);inventory.save(p);Sale sale=sales.checkout(p.id,2);
        assertEquals(new BigDecimal("39.98"),sale.total);assertEquals(3,inventory.list("").get(0).stock);assertEquals(1,sales.latest(20).size());
        assertThrows(IllegalArgumentException.class,()->sales.checkout(p.id,4));assertEquals(3,inventory.list("").get(0).stock);assertEquals(1,sales.latest(20).size());
    }

    private static Product product(String sku,String name,int stock){Product p=new Product();p.sku=sku;p.name=name;p.category="Pruebas";p.description="Registro ficticio de prueba";p.price=new BigDecimal("19.99");p.stock=stock;p.minStock=1;return p;}
}
