package pe.jheyvx.tech.network;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ApiServerTest {
    @Test void threadedJsonServerRespondsToClientPing() throws Exception {
        ApiServer server=new ApiServer("127.0.0.1",0);
        try{server.start();ApiClient client=new ApiClient("127.0.0.1",server.getPort());assertTrue(client.call("PING").getAsJsonObject().get("message").getAsString().contains("estable"));}
        finally{server.close();}
    }
}
