@echo off
setlocal
cd /d "%~dp0"
if not exist "target\JHEYVX-Tech-Desktop.jar" (
  echo No encuentro target\JHEYVX-Tech-Desktop.jar.
  echo Ejecuta primero mvn clean test package o descarga el ZIP completo del portafolio.
  pause
  exit /b 1
)
java -jar "target\JHEYVX-Tech-Desktop.jar"
if errorlevel 1 pause
