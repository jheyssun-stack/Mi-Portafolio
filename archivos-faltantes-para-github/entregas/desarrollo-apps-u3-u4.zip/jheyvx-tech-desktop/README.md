# JHEYVX TECH · aplicación de escritorio

Entrega académica para las semanas 9–16 de Desarrollo de Aplicaciones I. Continúa el tema de inventario y ventas de JHEYVX TECH que ya aparece en las semanas anteriores.

## Requisitos

- Windows, macOS o Linux.
- Java 8 o posterior para ejecutar el `.jar`.
- No requiere instalar un servidor ni crear una cuenta. H2 guarda la base de datos localmente en `data/`.

## Ejecutar

1. Descarga y extrae `desarrollo-apps-u3-u4.zip`.
2. Abre la carpeta `jheyvx-tech-desktop`.
3. Ejecuta `run.bat` en Windows, o en una terminal: `java -jar target/JHEYVX-Tech-Desktop.jar`.
4. El primer inicio crea la base y algunos productos de demostración. No borres la carpeta `data/` si quieres conservar tus cambios.

La interfaz Swing se comunica por TCP con un servicio local multihilo (127.0.0.1:8765); ese servicio accede a H2 mediante JDBC. El modo normal inicia ambos procesos dentro de la misma app.

## Opciones de demostración

- `java -jar target/JHEYVX-Tech-Desktop.jar --server`: inicia solamente el servicio local.
- `JHEYVX_SERVER_HOST=127.0.0.1 java -jar target/JHEYVX-Tech-Desktop.jar --client`: abre la interfaz y se conecta al servicio indicado.
- El puerto predeterminado es `8765`; se puede cambiar con `JHEYVX_SERVER_PORT`.

El servicio no implementa autenticación ni cifrado; déjalo ligado a `localhost` y no lo expongas a Internet.

## Funciones

- Inventario: buscar, crear, editar y desactivar productos.
- Ventas: seleccionar artículos, validar existencias, descontar stock y registrar cada venta en una transacción.
- Resumen: consultar conteos y alertas de stock bajo.
- Esquema relacional con claves foráneas y restricciones.
- Pruebas automatizadas de persistencia, validación, transacción y comunicación TCP.

## Compilar y ejecutar pruebas

Con JDK 8+ y Maven 3.9+:

```powershell
mvn clean test package
```

El JAR autocontenido queda en `target/JHEYVX-Tech-Desktop.jar`. La base de datos se crea junto al directorio desde donde se inicia el programa.

## Correspondencia con el sílabo

- 9: JDBC y conexión con la base relacional.
- 10: inserción y consulta.
- 11: actualización, baja lógica y transacciones.
- 12: tabla dinámica de inventario.
- 13: arquitectura cliente-servidor y pool de hilos.
- 14: validaciones, excepciones y pruebas.
- 15: empaquetado del ejecutable `.jar`.
- 16: demostración del proyecto integrado.

La página del portafolio sirve como ficha y descarga; una app Swing no se ejecuta dentro del navegador.
